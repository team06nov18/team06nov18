<!DOCTYPE html>
<html>
<head>
	<title> car sell</title>
</head>

<body>
<!-- 
<div id="footer" class="container-fluid bg-secondary mt-3" style="border-radius: 5px;">
    	<h3 class="text-center font-weight-bold text-white" style="padding-bottom: 5px;">Design by 007 - 2018</h3> -->
    	<footer style="background-color: #6c757d; border-top: 5px double black;border-bottom: 5px double black; margin-bottom: 1%;" class="py-3 bg-light">
      <div class="container">
        <div class="copy-agile-right text-center">
          
          <p> 
            © 2018 Car Sell. All Rights Reserved | Design by <a href="index.php" target="_blank">team06nov2018</a>
          </p>
        </div>
      </div>
    </footer>
    
</div>
</body>
</html>