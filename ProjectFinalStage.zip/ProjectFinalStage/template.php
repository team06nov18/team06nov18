<!DOCTYPE html>
<?php
//must appear BEFORE the <html> tag
session_start();
include_once('confige.php');
?>
<html>
<head>
	<title></title>

</head>
<?php include('header.php'); ?>
<body>

</body>
</html>
<?php include('footer.php'); ?>
