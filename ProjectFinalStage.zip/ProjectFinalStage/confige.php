<?php
//define constants for connection info
define("MYSQLUSER","team06nov18");
define("MYSQLPASS","Darla@1335");
define("HOSTNAME","localhost");
define("MYSQLDB","team06nov18_cars");

//make connection to database
function db_connect()
{
	$conn = @new mysqli(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);
	if($conn -> connect_error) {
		die('Connect Error: ' . $conn -> connect_error);
	}
	return $conn;
} 
?>


